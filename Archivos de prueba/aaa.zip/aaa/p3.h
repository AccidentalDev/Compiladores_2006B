CONSTANTES [
   MAX<-5, F<-FALSO, MAX<-5, CERO<-0
]

VARIABLES [
   ENTERO a,a,b<-1.0,z;
   CADENA b,F,k;
   REAL c<-d
]

ARREGLOS [
   ENTERO c{2},e{2,4}<-[[1.0,2,3],[4.0,5,6,7,8]];
   REAL f{1},g{0,40000}
]

REGISTROS [
   h[ENTERO h,a,d,F];
   i[REAL i]{a}
]

PROTOTIPOS [
   FUNCION F {} ENTERO;
   FUNCION a {ENTERO MAX} REAL;
   FUNCION f1 {ENTERO a,b,c} LOGICO;
   FUNCION f2 {REAL f1,f2;ENTERO f3{3,3}} CADENA;
   FUNCION f2 {} CADENA;
   PROCEDIMIENTO p3 {};
   PROCEDIMIENTO p4 {REAL d,e}
]

MODULOS [
   PROCEDIMIENTO p5 {}
   INICIO [
      REGRESAR(1)
   ] FIN
]
